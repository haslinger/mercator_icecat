-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Erstellungszeit: 14. Apr 2014 um 15:52
-- Server Version: 5.5.35-1ubuntu1
-- PHP-Version: 5.5.9-1ubuntu4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `mercator_development`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `property_groups`
--

CREATE TABLE IF NOT EXISTS `property_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name_de` varchar(255) DEFAULT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20702 ;

--
-- Daten für Tabelle `property_groups`
--

INSERT INTO `property_groups` (`id`, `name_de`, `name_en`, `position`, `created_at`, `updated_at`) VALUES
(20568, 'scope test', 'scope test', 910, '2014-02-04 18:16:45', '2014-02-04 18:16:45'),
(20569, 'Language', 'Language', 110, '2014-02-04 18:16:45', '2014-02-04 19:30:55'),
(20570, 'Technische Details', 'Technical details', 2, '2014-02-04 18:16:45', '2014-02-04 19:56:57'),
(20571, 'Systemanforderung', 'System requirements', 66, '2014-02-04 18:16:45', '2014-02-04 19:55:11'),
(20572, 'Gewicht u. Abmessungen', 'Weight & dimensions', 45, '2014-02-04 18:16:52', '2014-02-04 19:56:14'),
(20573, 'Klimabedingungen', 'Environmental conditions', 58, '2014-02-04 18:16:53', '2014-02-04 19:55:53'),
(20574, 'Druckqualität', 'Print quality', 35, '2014-02-04 18:16:53', '2014-02-04 19:56:46'),
(20575, 'Verpacken', 'Packaging data', 57, '2014-02-04 18:17:36', '2014-02-04 19:55:48'),
(20576, 'Farbe', 'Colour', 36, '2014-02-04 18:19:21', '2014-02-04 19:56:47'),
(20577, 'Zertifikate', 'Certificates', 1, '2014-02-04 18:19:38', '2014-02-04 19:56:56'),
(20578, 'Verbrauchsmaterialien', 'Consumables', 100, '2014-02-04 18:19:38', '2014-02-04 19:45:18'),
(20579, 'Energieverwaltung', 'Energy management', 38, '2014-02-04 18:19:39', '2014-02-04 19:56:47'),
(20580, 'Netzwerk', 'Networking', 14, '2014-02-04 18:19:39', '2014-02-04 19:56:54'),
(20581, 'Audio Emission', 'Sound emission', 65, '2014-02-04 18:19:39', '2014-02-04 19:55:14'),
(20582, 'Speicher', 'Memory', 27, '2014-02-04 18:19:39', '2014-02-04 19:56:50'),
(20583, 'KonnektivitÃ¤t', 'Connectivity', 49, '2014-02-04 18:19:41', '2014-02-04 19:56:15'),
(20584, 'Drucktechnologie', 'Print technology', 39, '2014-02-04 18:19:41', '2014-02-04 19:56:48'),
(20585, 'Papierbehandlung', 'Paper handling', 29, '2014-02-04 18:19:41', '2014-02-04 19:56:43'),
(20586, 'DruckqualitÃ¤t', 'Print quality', 67, '2014-02-04 18:19:42', '2014-02-04 19:55:19'),
(20587, 'Druckgeschwindigkeit', 'Printing', 34, '2014-02-04 18:19:43', '2014-02-04 19:56:46'),
(20588, 'Laufwerk', 'Disk drive', 53, '2014-02-04 18:19:43', '2014-02-04 19:56:07'),
(20589, 'Betriebssystem/Software', 'Operating system/software', 37, '2014-02-04 18:19:43', '2014-02-04 19:56:47'),
(20590, 'Medienformat', 'Media formats', 40, '2014-02-04 18:19:43', '2014-02-04 19:56:48'),
(20591, 'Dauer', 'Endurance', 106, '2014-02-04 18:20:33', '2014-02-04 19:39:21'),
(20592, 'Ausgabeleistung', 'Output capacity', 41, '2014-02-04 18:20:40', '2014-02-04 19:56:48'),
(20593, 'EingangskapazitÃ¤t', 'Input capacity', 42, '2014-02-04 18:20:40', '2014-02-04 19:56:49'),
(20594, 'Prozessor', 'Processor', 15, '2014-02-04 18:20:41', '2014-02-04 19:56:54'),
(20595, 'Sicherheit', 'Security', 9, '2014-02-04 18:21:43', '2014-02-04 19:56:56'),
(20596, 'Media weight', 'Media weight', 108, '2014-02-04 18:21:43', '2014-02-04 19:32:28'),
(20597, 'Media types', 'Media types', 105, '2014-02-04 18:21:49', '2014-02-04 19:40:09'),
(20598, 'Fax', 'Fax', 31, '2014-02-04 18:25:46', '2014-02-04 19:56:44'),
(20599, 'Kopieren', 'Copying', 33, '2014-02-04 18:25:47', '2014-02-04 19:56:45'),
(20600, 'Scannen', 'Scanning', 32, '2014-02-04 18:25:48', '2014-02-04 19:56:44'),
(20601, 'Speichermedien', 'Storage', 26, '2014-02-04 18:25:49', '2014-02-04 19:56:51'),
(20602, 'Anzeige', 'Display', 28, '2014-02-04 18:25:50', '2014-02-04 19:56:42'),
(20603, 'EingabegerÃ¤t', 'Input device', 86, '2014-02-04 18:34:28', '2014-02-04 19:54:12'),
(20604, 'Audio', 'Audio', 43, '2014-02-04 18:42:16', '2014-02-04 19:56:36'),
(20605, 'Lautsprecher', 'Loudspeakers', 114, '2014-02-04 18:42:17', '2014-02-04 19:23:41'),
(20606, 'Ergonomie', 'Ergonomics', 60, '2014-02-04 18:42:17', '2014-02-04 19:55:39'),
(20607, 'Video', 'Video', 52, '2014-02-04 18:42:18', '2014-02-04 19:56:16'),
(20608, 'BildschirmauflÃ¶sung', 'Display resolution', 119, '2014-02-04 18:42:18', '2014-02-04 19:05:41'),
(20609, 'DatenÃ¼bertragung', 'Data transmission', 50, '2014-02-04 18:42:22', '2014-02-04 19:56:15'),
(20610, 'Telefoneigenschaften', 'Phone features', 133, '2014-02-04 18:42:35', '2014-02-04 18:42:54'),
(20611, 'Camera', 'Camera', 62, '2014-02-04 18:42:36', '2014-02-04 19:55:41'),
(20612, 'Wireless LAN features', 'Wireless LAN features', 116, '2014-02-04 18:42:36', '2014-02-04 19:16:56'),
(20613, 'Tastatur', 'Keyboard', 48, '2014-02-04 18:42:38', '2014-02-04 19:56:15'),
(20614, 'GPS Leistung', 'GPS Performance', 99, '2014-02-04 18:42:39', '2014-02-04 19:46:12'),
(20615, 'optisches Laufwerk', 'Optical drive', 51, '2014-02-04 18:43:09', '2014-02-04 19:56:15'),
(20616, 'Video Speicher', 'Video memory', 107, '2014-02-04 18:43:17', '2014-02-04 19:32:56'),
(20617, 'ErweiterungssteckplÃ¤tze', 'Expansion slots', 95, '2014-02-04 18:43:29', '2014-02-04 19:53:27'),
(20618, 'Konnektivität', 'Ports & interfaces', 6, '2014-02-04 18:45:14', '2014-02-04 19:56:57'),
(20619, 'Writing speed', 'Writing speed', 132, '2014-02-04 18:45:25', '2014-02-04 18:45:25'),
(20620, 'Protokolle', 'Protocols', 10, '2014-02-04 18:45:53', '2014-02-04 19:56:56'),
(20621, 'Bandbreite', 'Bandwidth', 109, '2014-02-04 18:46:01', '2014-02-04 19:32:05'),
(20622, 'Management features', 'Management features', 64, '2014-02-04 18:46:02', '2014-02-04 19:55:37'),
(20623, 'Projektor', 'Projector', 118, '2014-02-04 18:48:28', '2014-02-04 19:16:25'),
(20624, 'Abtastungfrequenz', 'Scanning frequency', 131, '2014-02-04 18:48:28', '2014-02-04 18:48:28'),
(20625, 'Objektivsystem', 'Lens system', 124, '2014-02-04 18:48:28', '2014-02-04 18:49:33'),
(20626, 'Lampen', 'Lamps', 117, '2014-02-04 18:48:28', '2014-02-04 19:16:25'),
(20627, 'Light metering', 'Light metering', 125, '2014-02-04 18:49:01', '2014-02-04 18:49:34'),
(20628, 'Weissabgleich', 'White balance', 129, '2014-02-04 18:49:01', '2014-02-04 18:49:01'),
(20629, 'Blitz', 'Flash', 121, '2014-02-04 18:49:04', '2014-02-04 18:49:32'),
(20630, 'Exposure modes', 'Exposure modes', 130, '2014-02-04 18:49:04', '2014-02-04 18:49:04'),
(20631, 'Belichtung', 'Light exposure', 122, '2014-02-04 18:49:04', '2014-02-04 18:49:32'),
(20632, 'Bildsensor', 'Image sensor', 123, '2014-02-04 18:49:04', '2014-02-04 18:49:33'),
(20633, 'BildqualitÃ¤t', 'Picture quality', 128, '2014-02-04 18:49:05', '2014-02-04 18:49:19'),
(20634, 'Scene modes', 'Scene modes', 120, '2014-02-04 18:49:09', '2014-02-04 18:49:24'),
(20635, 'Viewfinder', 'Viewfinder', 126, '2014-02-04 18:49:11', '2014-02-04 18:49:26'),
(20636, 'Fokussierung', 'Focusing', 127, '2014-02-04 18:49:12', '2014-02-04 18:49:26'),
(20637, 'TV Tuner', 'TV tuner', 59, '2014-02-04 18:50:36', '2014-02-04 19:55:55'),
(20638, 'Material', 'Material', 103, '2014-02-04 19:05:43', '2014-02-04 19:43:18'),
(20639, 'Eingangskapazität', 'Input capacity', 30, '2014-02-04 19:06:41', '2014-02-04 19:56:43'),
(20640, 'Laufwerk Controller', 'Storage controllers', 96, '2014-02-04 19:07:14', '2014-02-04 19:52:38'),
(20641, 'Datenübertragung', 'Data transmission', 5, '2014-02-04 19:08:55', '2014-02-04 19:56:57'),
(20642, 'Ablichtung/Warnungen', 'Illumination/Alarms', 63, '2014-02-04 19:11:34', '2014-02-04 19:55:35'),
(20643, 'Lizenz', 'License', 111, '2014-02-04 19:14:05', '2014-02-04 19:30:56'),
(20644, 'Bildschirmauflösung', 'Display resolution', 115, '2014-02-04 19:14:34', '2014-02-04 19:19:47'),
(20645, 'Umweltbedingungen', 'Environmental conditions', 104, '2014-02-04 19:15:31', '2014-02-04 19:40:16'),
(20646, 'Eingabegerät', 'Input device', 12, '2014-02-04 19:16:51', '2014-02-04 19:56:55'),
(20647, 'Energiemanagement', 'Power', 3, '2014-02-04 19:17:10', '2014-02-04 19:56:57'),
(20648, 'Diskettenlaufwerk', 'Disk drive', 55, '2014-02-04 19:17:12', '2014-02-04 19:56:08'),
(20649, 'Festplattenlaufwerk', 'Disk drive', 54, '2014-02-04 19:24:01', '2014-02-04 19:56:08'),
(20650, 'Chassis', 'Chassis', 94, '2014-02-04 19:24:19', '2014-02-04 19:53:27'),
(20651, 'Erweiterungssteckplätze', 'Expansion slots', 68, '2014-02-04 19:24:20', '2014-02-04 19:54:58'),
(20652, 'Other features', 'Other features', 113, '2014-02-04 19:25:12', '2014-02-04 19:28:44'),
(20653, 'Battery', 'Battery', 46, '2014-02-04 19:28:27', '2014-02-04 19:56:14'),
(20654, 'Receiver', 'Receiver', 93, '2014-02-04 19:28:36', '2014-02-04 19:53:48'),
(20655, 'Verpackungsinhalt', 'Packaging content', 44, '2014-02-04 19:29:08', '2014-02-04 19:56:13'),
(20656, 'Thin Client', 'Thin Client', 61, '2014-02-04 19:29:08', '2014-02-04 19:55:41'),
(20657, 'Ausdauer', 'Endurance', 112, '2014-02-04 19:29:14', '2014-02-04 19:29:14'),
(20658, 'Betriebsbedingungen', 'Operational conditions', 56, '2014-02-04 19:30:06', '2014-02-04 19:55:47'),
(20659, 'weitere Spezifikationen', 'Other features', 7, '2014-02-04 19:30:49', '2014-02-04 19:56:55'),
(20660, 'Grafik', 'Graphics', 20, '2014-02-04 19:30:49', '2014-02-04 19:56:55'),
(20661, 'Special features', 'Special features', 47, '2014-02-04 19:31:18', '2014-02-04 19:56:14'),
(20662, 'Management-Funktionen', 'Management features', 8, '2014-02-04 19:31:50', '2014-02-04 19:56:56'),
(20663, 'Kamera', 'Camera', 19, '2014-02-04 19:34:29', '2014-02-04 19:56:55'),
(20664, 'Mouse', 'Mouse', 85, '2014-02-04 19:39:25', '2014-02-04 19:54:11'),
(20665, 'Batterie', 'Battery', 21, '2014-02-04 19:41:17', '2014-02-04 19:56:52'),
(20666, 'Nachrichtenübermittlung', 'Messaging', 101, '2014-02-04 19:43:22', '2014-02-04 19:43:22'),
(20667, 'Kartenlesegerät', 'Card reader', 102, '2014-02-04 19:43:25', '2014-02-04 19:43:25'),
(20668, 'Optisches Kabel', 'Optical fiber', 97, '2014-02-04 19:44:32', '2014-02-04 19:50:37'),
(20669, 'Sensoren', 'Sensors', 98, '2014-02-04 19:46:03', '2014-02-04 19:46:03'),
(20670, 'Gewicht & Abmessungen', 'Weight & dimensions', 4, '2014-02-04 19:51:49', '2014-02-04 19:56:57'),
(20671, 'Schutzfunktion', 'Protection features', 92, '2014-02-04 19:53:51', '2014-02-04 19:53:51'),
(20672, 'Fächer', 'Compartments', 91, '2014-02-04 19:53:55', '2014-02-04 19:53:55'),
(20673, 'Gewicht', 'Weight', 75, '2014-02-04 19:53:56', '2014-02-04 19:54:21'),
(20674, 'Höhe', 'Height', 83, '2014-02-04 19:53:56', '2014-02-04 19:54:10'),
(20675, 'Tiefe', 'Depth', 76, '2014-02-04 19:53:56', '2014-02-04 19:54:21'),
(20676, 'Breite', 'Width', 77, '2014-02-04 19:53:56', '2014-02-04 19:54:21'),
(20677, 'Maximaler Bildschirmdurchmesser', 'Maximum screen size compatibility', 90, '2014-02-04 19:53:56', '2014-02-04 19:53:57'),
(20678, 'Typ', 'Type', 89, '2014-02-04 19:53:58', '2014-02-04 19:53:58'),
(20679, 'Lautsprecher Hersteller', 'Speakers manufacturer', 87, '2014-02-04 19:54:02', '2014-02-04 19:54:02'),
(20680, 'Maximaler Hauptspeicher', 'Maximum internal memory', 88, '2014-02-04 19:54:02', '2014-02-04 19:54:02'),
(20681, 'Empfohlene Benutzung', 'Recommended usage', 84, '2014-02-04 19:54:10', '2014-02-04 19:54:10'),
(20682, 'Abmessungen (BxTxH)', 'Dimensions (WxDxH)', 82, '2014-02-04 19:54:12', '2014-02-04 19:54:12'),
(20683, 'Gewicht mit Untersatz', 'Weight with stand', 71, '2014-02-04 19:54:20', '2014-02-04 19:54:20'),
(20684, 'Gerätehöhe (inkl. Fuß)', 'Height (with stand)', 72, '2014-02-04 19:54:20', '2014-02-04 19:54:20'),
(20685, 'Gerätetiefe (inkl. Fuß)', 'Depth (with stand)', 73, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20686, 'Gerätebreite (inkl. Fuß)', 'Width (with stand)', 74, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20687, 'Höheneinstellung', 'Height adjustment', 78, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20688, 'Horizontaler Scanbereich', 'Horizontal scan range', 79, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20689, 'Pixel Abstand', 'Pixel pitch', 80, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20690, 'Bildschirmdiagonale (cm)', 'Display diagonal', 81, '2014-02-04 19:54:21', '2014-02-04 19:54:21'),
(20691, 'Intel Active Management Technology', 'Processor special features', 16, '2014-02-04 19:54:25', '2014-02-04 19:56:54'),
(20692, 'Intel HD Audio Technology', 'Processor special features', 23, '2014-02-04 19:54:25', '2014-02-04 19:56:52'),
(20693, 'Intel Matrix Storage Technology', 'Processor special features', 24, '2014-02-04 19:54:25', '2014-02-04 19:56:52'),
(20694, 'Intel Smart Connect Technologie', 'Processor special features', 25, '2014-02-04 19:54:25', '2014-02-04 19:56:53'),
(20695, 'Intel Rapid Start Technologie', 'Processor special features', 18, '2014-02-04 19:54:25', '2014-02-04 19:56:54'),
(20696, 'Intel Identity Protection Technologie', 'Processor special features', 70, '2014-02-04 19:54:25', '2014-02-04 19:54:25'),
(20697, 'Intel visual Technologien', 'Processor special features', 69, '2014-02-04 19:54:25', '2014-02-04 19:54:36'),
(20698, 'Intel Smart Response Technologie', 'Processor special features', 17, '2014-02-04 19:54:25', '2014-02-04 19:56:54'),
(20699, 'Prozessor Besonderheiten', 'Processor special features', 13, '2014-02-04 19:55:49', '2014-02-04 19:56:53'),
(20700, 'Design', 'Design', 22, '2014-02-04 19:56:52', '2014-02-04 19:56:52'),
(20701, 'Wireless LAN Charakteristiken', 'Wireless LAN features', 11, '2014-02-04 19:56:56', '2014-02-04 19:56:56');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
